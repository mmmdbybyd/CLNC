"${0%/*}"/Core/CuteBi start
#iptables -t nat -I OUTPUT -p 17 --dport 53 -j ACCEPT